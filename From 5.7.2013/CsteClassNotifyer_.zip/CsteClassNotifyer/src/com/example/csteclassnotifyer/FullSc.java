package com.example.csteclassnotifyer;

import android.app.Activity;
import android.os.Bundle;

public class FullSc extends Activity{

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.fullsd);
	}
	
	
	

}
