/** Automatically generated file. DO NOT MODIFY */
package com.example.graphics2d;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}